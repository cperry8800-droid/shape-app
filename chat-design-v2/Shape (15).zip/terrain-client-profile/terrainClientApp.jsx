// ═══════════════════════════════════════════════════════════════
// TERRAIN · Client profile — standalone mobile app
// Renders the TERRAIN living-identity direction for the member (client)
// persona only. Full-bleed on phones (PWA-style); framed phone on desktop.
// Variant switch: Public · Own (editable) · Private (locked).
// Deps: livingShared, livingClientHeroes, livingTerrain, ios-frame.
// ═══════════════════════════════════════════════════════════════

const tcaMono = "'JetBrains Mono', monospace";
const tcaSerif = "'Fraunces', serif";

function useViewportPhone(bp = 560) {
  const [phone, setPhone] = React.useState(() => window.innerWidth <= bp);
  React.useEffect(() => {
    const on = () => setPhone(window.innerWidth <= bp);
    window.addEventListener("resize", on);
    return () => window.removeEventListener("resize", on);
  }, [bp]);
  return phone;
}

const TCA_VARIANTS = [["public", "Public"], ["own", "Own"], ["locked", "Private"]];

function VariantSwitch({ val, set, phone }) {
  return (
    <div style={{
      display: "inline-flex", gap: 3, padding: 4, borderRadius: 999,
      background: "rgba(242,237,228,0.06)", border: "1px solid rgba(242,237,228,0.1)",
      backdropFilter: "blur(12px)",
    }}>
      {TCA_VARIANTS.map(([v, l]) => {
        const on = val === v;
        return (
          <button key={v} onClick={() => set(v)} style={{
            padding: phone ? "8px 16px" : "7px 15px", borderRadius: 999, border: 0, cursor: "pointer",
            fontFamily: "'Space Grotesk', sans-serif", fontSize: 12.5, fontWeight: on ? 600 : 400,
            background: on ? "#1ec0a8" : "transparent", color: on ? "#06110e" : "rgba(242,237,228,0.6)",
            whiteSpace: "nowrap", transition: "background .15s, color .15s",
          }}>{l}</button>
        );
      })}
    </div>
  );
}

function TerrainClientApp() {
  const phone = useViewportPhone();
  const [variant, setVariant] = React.useState(() => {
    try { return localStorage.getItem("tca-variant") || "public"; } catch (e) { return "public"; }
  });
  const set = (v) => { setVariant(v); try { localStorage.setItem("tca-variant", v); } catch (e) {} };

  // ── Phone viewport: full-bleed app, no bezel ──
  if (phone) {
    return (
      <div style={{ position: "fixed", inset: 0, background: "#100d0a", display: "flex", flexDirection: "column" }}>
        <div style={{ flex: 1, minHeight: 0, position: "relative" }}>
          <TerrainProfile key={"client" + variant} persona="client" variant={variant} />
        </div>
        {/* floating variant switch */}
        <div style={{ position: "fixed", top: "calc(env(safe-area-inset-top, 0px) + 8px)", left: "50%", transform: "translateX(-50%)", zIndex: 80, pointerEvents: "auto" }}>
          <VariantSwitch val={variant} set={set} phone />
        </div>
      </div>
    );
  }

  // ── Desktop: framed phone, centered, with header + switch ──
  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", padding: "40px 20px 56px" }}>
      <header style={{ textAlign: "center", maxWidth: 560 }}>
        <div style={{ fontFamily: tcaMono, fontSize: 11, letterSpacing: "0.24em", textTransform: "uppercase", color: "#1ec0a8" }}>Shape · Living identity · 02</div>
        <h1 style={{ fontFamily: tcaSerif, fontSize: 60, fontWeight: 400, letterSpacing: "-0.04em", lineHeight: 0.9, margin: "16px 0 0" }}>Terrain<span style={{ fontStyle: "italic" }}> · client</span></h1>
        <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 15.5, lineHeight: 1.55, color: "rgba(242,237,228,0.6)", margin: "16px auto 0", maxWidth: 460, textWrap: "pretty" }}>
          A member's profile as a topographic ascent — start, through Now, toward the summit goal. Procedurally composed from their own data.
        </p>
      </header>
      <div style={{ marginTop: 26 }}>
        <VariantSwitch val={variant} set={set} />
      </div>
      <div style={{ marginTop: 30 }}>
        <IOSDevice dark={true} width={390} height={800}>
          <TerrainProfile key={"client" + variant} persona="client" variant={variant} />
        </IOSDevice>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<TerrainClientApp />);
