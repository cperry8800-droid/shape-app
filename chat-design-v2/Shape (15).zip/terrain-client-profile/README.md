# Terrain · Client Profile — Mobile Design Handoff

The **member (client) living-identity profile**, "Terrain" direction. A member's
profile rendered as a topographic ascent: contour field + ridgeline from start →
Now → summit goal, procedurally composed from their own data. This package is the
complete, self-contained source for that one screen — nothing else from the parent
project is required.

## What's in here (6 files)

| File | Role |
|------|------|
| `index.html` | Entry point. Loads fonts + React/Babel from CDN, then the 5 scripts **in the order below**. |
| `livingShared.jsx` | Design tokens, helpers, and shared UI (portrait, crest, status bar, sticky bar, dock, goal bar, week bars, sparkline). **Load 1st.** |
| `livingClientHeroes.jsx` | Client-specific hero treatments (ascent chart header, etc). **Load 2nd.** |
| `livingTerrain.jsx` | The Terrain direction: generative contour field, ridgeline, and the `TerrainProfile` screen component. **Load 3rd.** |
| `ios-frame.jsx` | `IOSDevice` phone bezel — desktop preview only; ignore for native. **Load 4th.** |
| `terrainClientApp.jsx` | App shell. Full-bleed on phones, framed phone on desktop, with the Public/Own/Private variant switch. Mounts to `#root`. **Load last.** |

**Load order matters** — each file references symbols defined in the ones above it.
Don't reorder the `<script>` tags.

## Run it
Open `index.html` in any browser (or serve the folder). No build step — JSX is
transpiled in-browser by Babel. On a phone-width viewport it renders full-bleed;
on desktop it shows inside a phone bezel with a header.

## Three variants (the switch at top)
- **Public** — how anyone sees this member.
- **Own** — the member's own editable view (add/replace photo, privacy, edit identity).
- **Private** — locked state. Persisted to `localStorage` key `tca-variant`.

## Design tokens (for the native rebuild)
```
Background   #100d0a   (LV_BG, near-black warm)
Ink / text   #f2ede4   (LV_INK, warm off-white)
Accent teal  #1ec0a8   (LV_TEAL — "live / now / message")
Teal bright  #2ee0c4   (LV_TEALB)
```
**Momentum tiers** set each screen's atmosphere color (glow + accents):
Spark `#e8743a` · Tempo `#5ec8e0` · (see `LV_TIERS` in `livingShared.jsx` for the full set).

**Type**
- Serif / display — **Fraunces** (`lvSerif`)
- Sans / UI — **Space Grotesk** (`lvSans`)
- Mono / labels — **JetBrains Mono** (`lvMono`)

## Notes for porting to native
- **Images** are remote Unsplash URLs built by `lvPortraitURL(id, size)` in
  `livingShared.jsx` — no local image assets to ship. Swap this for your real
  member-photo source.
- **Generative art** (contours, ridgeline, crest, sparkline) is pure SVG driven by
  a seeded RNG (`lvRng(seed)`) — deterministic per member. Reproduce the seed →
  same landscape every time.
- **Data shape**: a member object `d` carries `name`, `tier`, `seed`, `portrait`,
  `goalPct`, `goalShort`, `arc[]`, etc. The sample member data lives in
  `LV_PEOPLE` inside `livingShared.jsx` — use it as your schema reference.
- `ios-frame.jsx` is preview chrome only; drop it in the real app.
- Motion respects `prefers-reduced-motion` (see the `@keyframes` in `index.html`).
