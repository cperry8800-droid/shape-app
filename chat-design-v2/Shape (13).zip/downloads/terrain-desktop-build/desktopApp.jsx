// Desktop app wrapper — persona + variant controls, reads window.__DK.
// __DK = { direction: "terrain"|"signal", persona, personas:[...] }
const DK = window.__DK || { direction: "terrain", persona: "client", personas: ["client", "trainer", "nutritionist"] };

const DK_VARIANTS = [["public", "Public"], ["own", "Own"], ["locked", "Private"]];
const DK_PLABEL = { client: "Member", trainer: "Trainer", nutritionist: "Nutritionist" };

function DkSeg({ opts, val, set, accent }) {
  return (
    <div style={{ display: "inline-flex", gap: 3, padding: 4, borderRadius: 999, background: "rgba(242,237,228,0.06)", border: "1px solid rgba(242,237,228,0.1)" }}>
      {opts.map(([v, l]) => {
        const on = val === v;
        return (
          <button key={v} onClick={() => set(v)} style={{
            padding: "7px 15px", borderRadius: 999, border: 0, cursor: "pointer",
            fontFamily: "'Space Grotesk', sans-serif", fontSize: 12.5, fontWeight: on ? 600 : 400,
            background: on ? (accent || "#1ec0a8") : "transparent", color: on ? "#06110e" : "rgba(242,237,228,0.6)",
            whiteSpace: "nowrap", transition: "background .15s, color .15s",
          }}>{l}</button>
        );
      })}
    </div>
  );
}

function DesktopApp() {
  const [persona, setPersona] = React.useState(() => { try { return localStorage.getItem("dk-" + DK.direction + "-persona") || DK.persona; } catch (e) { return DK.persona; } });
  const [variant, setVariant] = React.useState(() => { try { return localStorage.getItem("dk-" + DK.direction + "-variant") || "public"; } catch (e) { return "public"; } });
  const setP = (v) => { setPersona(v); try { localStorage.setItem("dk-" + DK.direction + "-persona", v); } catch (e) {} };
  const setV = (v) => { setVariant(v); try { localStorage.setItem("dk-" + DK.direction + "-variant", v); } catch (e) {} };
  const personas = (DK.personas || ["client"]).map(p => [p, DK_PLABEL[p]]);

  return (
    <React.Fragment>
      <DesktopProfile key={DK.direction + persona + variant} direction={DK.direction} persona={persona} variant={variant} />
      {/* floating preview controls — not part of the page design itself */}
      <div style={{ position: "fixed", left: "50%", bottom: 22, transform: "translateX(-50%)", zIndex: 90, display: "flex", gap: 10, alignItems: "center", padding: 7, borderRadius: 999, background: "rgba(16,13,10,0.82)", backdropFilter: "blur(16px)", border: "1px solid rgba(242,237,228,0.12)", boxShadow: "0 10px 40px rgba(0,0,0,0.5)" }}>
        <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9.5, letterSpacing: "0.16em", textTransform: "uppercase", color: "rgba(242,237,228,0.4)", paddingLeft: 8 }}>Preview</span>
        {personas.length > 1 && <DkSeg opts={personas} val={persona} set={setP} accent={"#f2b84e"} />}
        <DkSeg opts={DK_VARIANTS} val={variant} set={setV} accent={"#1ec0a8"} />
      </div>
    </React.Fragment>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<DesktopApp />);
