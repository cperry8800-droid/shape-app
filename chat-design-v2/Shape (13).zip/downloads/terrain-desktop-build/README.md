# Shape · Terrain — Desktop website layout

The **Terrain** living-identity direction as a real desktop web page (not a
scaled phone): a sticky top nav, a split hero with the topographic contour
field + portrait medallion, a full-width "living signals" band, then a
two-column content grid (the climb ridgeline, discipline strata, the log feed
+ a sticky rail of records and relation). Collapses to one column on tablets
and phones.

## Run

Open `index.html`, or serve the folder (recommended — avoids local-file CORS
with the JSX modules):

```
npx serve .
```

## Files

- `index.html` — shell: fonts, React + Babel, Terrain motion CSS, responsive
  breakpoints, sets `window.__DK`, mounts the app.
- `livingDesktop.jsx` — **the desktop layout** (nav, hero, signals band, grid,
  feed, footer, locked state). Shared across directions; `direction="terrain"`
  selects the contour/ridge visuals.
- `livingTerrain.jsx` — the signature visuals: `TerrainContours`, `TerrainRidge`.
- `livingShared.jsx` — design system: tiers, people data, charts (`LvWeekBars`,
  `LvSparkline`), portrait, coach blocks, helpers.
- `desktopApp.jsx` — thin wrapper + the floating Preview controls (persona /
  variant). **Delete this and the `#root` mount in `index.html`, then render
  `<DesktopProfile direction="terrain" persona="client" variant="public" />`
  directly to drop the demo switcher.**

## Configure

`index.html` sets:

```js
window.__DK = { direction: "terrain", persona: "client",
                personas: ["client", "trainer", "nutritionist"] };
```

- `persona` — which profile to show first (`client` / `trainer` / `nutritionist`).
- `variant` — `public` (default), `own` (editable affordances), `locked` (private card).
- The floating control is a **preview helper only** — not part of the page design.

## Wire to real data

All content comes from `LV_PEOPLE` in `livingShared.jsx` (name, tier, score,
goal, disciplines, records, week/trajectory arrays, feed, relation). Replace
those objects with your own, or map your API to the same shape. Portraits use
Unsplash ids via `lvPortraitURL()` — swap that helper for your image pipeline.

Fonts required: **Fraunces**, **Space Grotesk**, **JetBrains Mono**.

No build step — JSX is transpiled in-browser by Babel. For production,
precompile the `.jsx` files with your bundler and drop the Babel `<script>`.
