# Shape · Signal — Desktop website layout

The **Signal** living-identity direction as a real desktop web page (not a
scaled phone): a sticky top nav, a split hero with the breathing instrument
(concentric discipline rings + cardiac week-trace + orbiting live blip, the
portrait as the core), a full-width "living signals" band, then a two-column
content grid (discipline ring-legend, the coach marketplace, the transmissions
feed + a sticky rail of records and relation). Collapses to one column on
tablets and phones.

## Run

Open `index.html`, or serve the folder (recommended — avoids local-file CORS
with the JSX modules):

```
npx serve .
```

## Files

- `index.html` — shell: fonts, React + Babel, Signal motion CSS, responsive
  breakpoints, sets `window.__DK`, mounts the app.
- `livingDesktop.jsx` — **the desktop layout** (nav, hero, signals band, grid,
  feed, footer, locked state). Shared across directions; `direction="signal"`
  selects the instrument visual.
- `livingSignal.jsx` — the signature visual: `SignalSigil` (rings + cardiac trace + core).
- `livingShared.jsx` — design system: tiers, people data, charts (`LvWeekBars`,
  `LvSparkline`), portrait, coach blocks, helpers.
- `desktopApp.jsx` — thin wrapper + the floating Preview controls (persona /
  variant). **Delete this and the `#root` mount in `index.html`, then render
  `<DesktopProfile direction="signal" persona="trainer" variant="public" />`
  directly to drop the demo switcher.**

## Configure

`index.html` sets:

```js
window.__DK = { direction: "signal", persona: "trainer",
                personas: ["trainer", "nutritionist", "client"] };
```

- `persona` — which profile to show first (`trainer` / `nutritionist` / `client`).
  Coaches surface the marketplace (certifications, services & prices, reviews);
  members surface their goal-progress gauge instead.
- `variant` — `public` (default), `own` (editable affordances), `locked` (private card).
- The floating control is a **preview helper only** — not part of the page design.

## Wire to real data

All content comes from `LV_PEOPLE` in `livingShared.jsx` (name, tier, score,
goal, disciplines, records, week/trajectory arrays, feed, certs, offerings,
reviews, relation). Replace those objects with your own, or map your API to the
same shape. Portraits use Unsplash ids via `lvPortraitURL()` — swap that helper
for your image pipeline.

Fonts required: **Fraunces**, **Space Grotesk**, **JetBrains Mono**.

No build step — JSX is transpiled in-browser by Babel. For production,
precompile the `.jsx` files with your bundler and drop the Babel `<script>`.
