# Shape · Facet avatar — drop-in build

The **Facet** avatar bubble: the avatar *is* a shape — a soft rounded-diamond gem,
tier-coloured from the edge, portrait upright inside, a rank wedge at the foot.
Live state shows a teal "lifting now" ring + dot.

## Files

- `avatarFacet.jsx` — the component, self-contained (own tier tokens). Exports
  `AvatarFacet` + `AvatarFacetStack` to `window`.
- `avatar-facet.css` — the two keyframes the live state needs (`.av-pulse`, `.av-pulse-dot`).
- `index.html` — a runnable demo (context row, states, scales, stack).

## Try it

Open `index.html`, or serve the folder:

```
npx serve .
```

## Add to your current build

1. Copy `avatarFacet.jsx` into your project.
2. Merge `avatar-facet.css` into your global stylesheet (or link it).
3. Make sure these fonts are loaded: **Fraunces** (initials), **JetBrains Mono** (rank).
4. Mount it:

```jsx
// no photo → tier-coloured gem with the initial
<AvatarFacet tier="apex" initial="M" size={56} />

// with a photo (Unsplash id OR any full image URL)
<AvatarFacet tier="surge" photo="1544005313-94ddf0286df2" size={56} live />

// overlapping "who's on now" row
<AvatarFacetStack size={40} more="+212 near you" members={[
  { tier: "surge", photo: "…", live: true },
  { tier: "tempo", initial: "C" },
]} />
```

### Props

| prop | type | default | notes |
|------|------|---------|-------|
| `tier` | `"spark" \| "tempo" \| "surge" \| "apex"` | `"surge"` | sets colour + rank |
| `photo` | Unsplash id **or** full image URL | — | omit to show `initial` |
| `initial` | string (1 char) | `"S"` | fallback when no photo |
| `size` | number (px) | `64` | everything scales from this |
| `live` | boolean | `false` | teal ring + pulse dot |
| `showRank` | boolean | `true` | rank wedge (auto-off inside stacks) |

### Wiring to real data

- **Photos:** `photo` accepts a full URL, so pass your own CDN/storage URL directly.
  To change the default pipeline, edit `facetPortrait()` at the top of `avatarFacet.jsx`.
- **Tiers:** colours + rank numerals live in `FACET_TIERS` — adjust to match your
  source of truth, or map your tier field to one of the four keys.
- **No build step:** the demo transpiles JSX in-browser via Babel. For production,
  precompile `avatarFacet.jsx` with your bundler and drop the Babel `<script>`.
