// ═══════════════════════════════════════════════════════════════
// SHAPE · Avatar bubble — FACET
// The avatar IS a shape: a soft rounded-diamond gem, tier-coloured from
// the edge, portrait upright inside, a rank wedge at the foot. Live =
// a teal facet-ring breathes around it.
//
// Self-contained (own tokens). Drop into any React build. Requires the
// keyframes in avatar-facet.css (.av-pulse / .av-pulse-dot).
//
// <AvatarFacet tier="surge" photo="1544005313-94ddf0286df2" size={56} live />
// <AvatarFacet tier="apex"  initial="M" size={56} />
// ═══════════════════════════════════════════════════════════════

const FACET_BG   = "#100d0a";
const FACET_INK  = "#f2ede4";
const FACET_TEAL = "#1ec0a8";

// Momentum tiers — the avatar's colour + rank come from here.
const FACET_TIERS = {
  spark: { name: "Spark", color: "#e8743a", rank: "I" },
  tempo: { name: "Tempo", color: "#5ec8e0", rank: "II" },
  surge: { name: "Surge", color: "#f0653f", rank: "III" },
  apex:  { name: "Apex",  color: "#f2b84e", rank: "IV" },
};

const _fa  = (hex, a) => { const n = parseInt(hex.slice(1), 16); return `rgba(${(n>>16)&255},${(n>>8)&255},${n&255},${a})`; };
const _fsh = (hex, f) => { const n = parseInt(hex.slice(1), 16); return `rgb(${Math.round(((n>>16)&255)*f)},${Math.round(((n>>8)&255)*f)},${Math.round((n&255)*f)})`; };

// Portrait source — swap this for your own image pipeline. Given a bare
// Unsplash id it returns a face-cropped square; given a full URL it is
// returned as-is.
function facetPortrait(src, s = 160) {
  if (!src) return null;
  if (/^https?:\/\//.test(src)) return src;
  return `https://images.unsplash.com/photo-${src}?w=${s}&h=${s}&fit=crop&crop=faces&q=72&auto=format`;
}

// props:
//   tier      "spark" | "tempo" | "surge" | "apex"   (default "surge")
//   photo     Unsplash id OR full image URL (optional → falls back to initial)
//   initial   single letter shown when no photo (default "S")
//   size      px (default 64)
//   live      boolean — teal "lifting now" ring + dot
//   showRank  boolean — show the rank wedge (default true; auto-off in stacks)
function AvatarFacet({ tier = "surge", photo, initial = "S", size = 64, live = false, showRank = true }) {
  const t = FACET_TIERS[tier] || FACET_TIERS.surge, c = t.color;
  const inset = Math.max(2, Math.round(size * 0.055));
  const src = facetPortrait(photo, Math.round(size * 2.4));
  return (
    <div style={{ width: size, height: size, position: "relative", display: "grid", placeItems: "center" }}>
      {live && (
        <div className="av-pulse" style={{ position: "absolute", inset: -Math.round(size * 0.12), transform: "rotate(45deg)", borderRadius: "30%", border: `2px solid ${FACET_TEAL}`, boxShadow: `0 0 12px ${_fa(FACET_TEAL, 0.55)}` }} />
      )}
      {/* gem frame */}
      <div style={{ position: "absolute", inset: 0, transform: "rotate(45deg)", borderRadius: "27%", background: `linear-gradient(135deg, ${c}, ${_fsh(c, 0.5)})`, boxShadow: `0 5px 16px ${_fa(c, 0.4)}, inset 1px 1px 2px ${_fa("#ffffff", 0.35)}` }}>
        <div style={{ position: "absolute", inset: 0, borderRadius: "27%", background: `linear-gradient(135deg, ${_fa("#ffffff", 0.28)}, transparent 42%)`, pointerEvents: "none" }} />
        {/* portrait window (rotated square clip → rounded diamond) */}
        <div style={{ position: "absolute", inset, borderRadius: "23%", overflow: "hidden", background: "#0f0c0a", display: "grid", placeItems: "center" }}>
          {src
            ? <img src={src} alt="" style={{ position: "absolute", width: "152%", height: "152%", left: "50%", top: "50%", transform: "translate(-50%,-50%) rotate(-45deg)", objectFit: "cover" }} />
            : <span style={{ transform: "rotate(-45deg)", fontFamily: "'Fraunces', serif", fontWeight: 500, fontSize: size * 0.42, color: FACET_INK, lineHeight: 1 }}>{initial}</span>}
        </div>
      </div>
      {/* rank wedge at the foot */}
      {showRank && !live && (
        <div style={{ position: "absolute", bottom: -Math.round(size * 0.02), left: "50%", width: Math.max(16, size * 0.30), height: Math.max(16, size * 0.30), transform: "translate(-50%,40%) rotate(45deg)", borderRadius: "30%", background: FACET_BG, display: "grid", placeItems: "center", boxShadow: `0 0 0 2px ${FACET_BG}` }}>
          <span style={{ transform: "rotate(-45deg)", fontFamily: "'JetBrains Mono', monospace", fontSize: Math.max(7, size * 0.13), fontWeight: 600, color: c }}>{t.rank}</span>
        </div>
      )}
      {/* live dot */}
      {live && (
        <div style={{ position: "absolute", bottom: 0, right: 0, transform: "translate(20%,20%)", background: FACET_BG, borderRadius: 999, padding: 3, boxShadow: `0 0 0 2px ${FACET_BG}` }}>
          <span className="av-pulse-dot" style={{ display: "block", width: Math.max(5, size * 0.09), height: Math.max(5, size * 0.09), borderRadius: 999, background: FACET_TEAL }} />
        </div>
      )}
    </div>
  );
}

// Optional: overlapping stack for "who's on now" rows.
function AvatarFacetStack({ members, size = 38, more }) {
  const overlap = Math.round(size * 0.42);
  return (
    <div style={{ display: "flex", alignItems: "center" }}>
      {members.map((m, i) => (
        <div key={i} style={{ marginLeft: i ? -overlap : 0, zIndex: members.length - i, filter: `drop-shadow(-3px 0 0 ${FACET_BG})` }}>
          <AvatarFacet {...m} size={size} showRank={false} />
        </div>
      ))}
      {more && <div style={{ marginLeft: 10, fontFamily: "'JetBrains Mono', monospace", fontSize: size * 0.3, letterSpacing: "0.04em", color: _fa(FACET_INK, 0.6) }}>{more}</div>}
    </div>
  );
}

// Export for non-module (Babel-in-browser) builds.
if (typeof window !== "undefined") {
  Object.assign(window, { AvatarFacet, AvatarFacetStack, FACET_TIERS });
}
